<div class="container-fluid">
	 <div class="row footer"><!--footer open-->
		<div class="col-sm-3" id="about">
			<center><h4 id="about"><b>About Us </b></h4></center>
						<hr />
				<p id="footerdata" />AK Construction has been in operation for the last 15 years but the team led by Akib Khan have been in the construction & design industries for over 40 years. We use our experience and expertise to deliver a top quality service with the projects we undertake.<b><a href="about.php">Click Here</a><br /></b></p>
			<hr />
		</div>
		<div class="col-sm-2 footerdata2">
			<center><h4 id="navigation"><b>NAVIGATION</b></h4></center>
			<hr />
				<a class="nav-link1" href="project.php">Home</a><br />
			  <a  class="nav-link1" href="contact.php">Contact us</a><br />
			  <a class="nav-link1" href="feedback.php">Feed Back	</a>
		</div>
		<div class="col-sm-3">
		<center><h4 id="social"><b>Follow Us</b></h4></center>
			<hr />
				<i class="fab fa-facebook-f fa-2x" aria-hidden="true" ></i>	&nbsp&nbsp
				<i class="fas fa-envelope fa-2x" aria-hidden="true"></i>&nbsp&nbsp
				<i class="fab fa-google fa-2x" aria-hidden="true"></i>&nbsp&nbsp
				<i class="fab fa-twitter fa-2x" aria-hidden="true"></i>	&nbsp&nbsp			
				<i class="fab fa-instagram fa-2x" aria-hidden="true"></i>
		</div>
		
		<div class="col-sm-3"id="contact">
			<center><h4 id="contact"><b>Contact Us</b></h4></center>
			<hr />
			<p>
			Post Code: 456335<br />

			Phone: +91-1234567890<br />
			
			Email: Akconstruction@gmail.com</p>
		</div>
	</div><!--footer close-->
</div>	<!--container close-->
	